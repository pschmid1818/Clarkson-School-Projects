from django.apps import AppConfig


class F4Config(AppConfig):
    name = 'f4'
