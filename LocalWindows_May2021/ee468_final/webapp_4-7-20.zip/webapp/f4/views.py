from django.shortcuts import get_object_or_404, render
from django.http import HttpResponse, HttpResponseRedirect
from django.urls import reverse
from django.views import generic

from .models import Teaches

def index(request):
    data = Teaches.objects.order_by('course_id')
    context = {'data' : data}
    return render(request, 'f4/index.html', context)

