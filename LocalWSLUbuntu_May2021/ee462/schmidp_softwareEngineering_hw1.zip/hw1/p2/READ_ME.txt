run in WSL Ubuntu

$ ./fc.sh
[Using pwd: /home/schmidp/ee462/hw1/p2]
4

./fc.sh temp23542345243
[temp23542345243 is not a directory]
[Using pwd: /home/schmidp/ee462/hw1/p2]
4

$ ./fc.sh t1.txt
[t1.txt is not a directory]
[Using pwd: /home/schmidp/ee462/hw1/p2]
4

$ ./fc.sh dir2/
2



