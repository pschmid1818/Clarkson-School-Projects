//precondition: x>=2
//if x is prime, returns 1, otherwise returns 0
int isPrime(int x);


// precondition: num >= 1
// prints factors of num
void printFactors(int num);