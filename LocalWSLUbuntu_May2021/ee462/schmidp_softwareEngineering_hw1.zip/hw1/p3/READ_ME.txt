run in WSL Ubuntu

$ ./bckup.sh /etc/hosts
$ echo $?
0

$ ./bckup.sh bckup.sh
$ echo $?
0

$ ls /tmp/schmidp
bckup.sh_06Feb21_2056.bk  hosts_06Feb21_2055.bk
