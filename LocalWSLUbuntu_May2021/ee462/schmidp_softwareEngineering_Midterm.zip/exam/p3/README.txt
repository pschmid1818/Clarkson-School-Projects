Midterm Part 2

To Compile: gcc driver3.c -L /data/class/ee462sp21/public/p3/lib/ - l libsimrand.a -o driver3 -std=c99

Output:
$ ./driver3
40686
243.906372