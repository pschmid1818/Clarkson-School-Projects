Midterm Part 1

To Compile: make

Output:
$ ./piclient

Set 1: {10, -3, 88, 765, 21}
Unable to add 190 to intSet

Set 2: {100, 200}

Top of Stack: {100, 200}
Top of Stack: {10, -3, 88, 765, 21}
