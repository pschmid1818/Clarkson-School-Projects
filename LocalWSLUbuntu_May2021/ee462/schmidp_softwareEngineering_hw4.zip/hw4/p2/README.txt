Compile with: n/a
Run with: bash comb.sh filler4.txt

---- Output ----
$ bash comb.sh filler4.txt
prog2 [space count]: 851
prog3 [line count]: 40