#!/usr/bin/env bash
echo "prog3 [line count]: `wc -l`"


