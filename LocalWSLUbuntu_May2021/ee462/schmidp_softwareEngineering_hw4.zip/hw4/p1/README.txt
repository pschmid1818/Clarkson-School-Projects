Compile with: gcc dusort.c -o dusort
Run with    : ./dusort

---- Ouput ----
$ gcc dusort.c -o dusort
$ ./dusort
Directory changed to: /usr/local
1.6M    ./ibm/gsk8_64/lib64/C
1.6M    ./ibm/gsk8_64/lib64/C/icc
1.6M    ./ibm/gsk8_64/lib64/C/icc/icclib
2.4M    ./ibm/gsk8_64/lib64/N
2.4M    ./ibm/gsk8_64/lib64/N/icc
2.4M    ./ibm/gsk8_64/lib64/N/icc/icclib
4.0K    ./share
4.0K    ./share/applications
15M     ./ibm/gsk8_64/bin
16M     ./ibm/gsk8_64/lib64
30M     .
30M     ./ibm
30M     ./ibm/gsk8_64
36K     ./sbin
