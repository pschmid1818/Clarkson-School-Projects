Compile with: gcc cmax.c -pthread -std=c99 -o cmax
Run with:     ./cmax

data4 directory included in zip for ease 

---- Output ----
$ ./cmax
Creating thread 1
Creating thread 2
Creating thread 3
Max for inp_2.txt is: 273
Max for inp_1.txt is: 32290
Max for inp_3.txt is: 3900
$ cat data4/out_1.txt; cat data4/out_2.txt; data4/cat out_3.txt
32290
273
3900

