#include "tok.h" // Grabs characters from stdin and creates tokens 
#include "io.h" // Importing syscalls & file handling including printing & scanning
#include "shtypes.h" // Importing the command struct
#include "parser.h" // Consumes tokens and creates command structs
#include "exec.h" // Functions that handle built-ins and run programs (execvp)
#include "syscalls.h" // Import more syscalls and define fork1

//character matrix of 10 100 length strings, larger number the number the newer the command
char history[10][100] = {"", "", "", "", "", "", "", "", "", ""};

/*argc : number of argumnets, argv : the arguments itself */
int main(int argc, char **argv)
{
	char *input = malloc(100 * sizeof(char)); // User input
	int input_len; // Length of user input
	struct cmd *c; // Pointer to a command struct
	int child; // Child process pid

	// Already written: Prints out a banner telling the user about the shell.
	printf("simple sh, " __DATE__ " " __TIME__ "\nPress Control+C or Control+D to exit.\n");

	// Already written: Initialize the tokenizer.
	advance();

	char cwd[200];
	char host[50];
	char user[50];

	do {
		// Prompt for username@hostname:current/working/directory$
		getcwd(cwd, sizeof(cwd));
		gethostname(host, sizeof(host));
		//everything I've tried to use gives a broken string in WSL Ubuntu
			//user = getlogin() gave (null)
			//getpwuid(getuid()) also gave garbled string
		getlogin_r(user, sizeof(user));

		printf("%s@%s:%s$ ", user, host, cwd); // Implementation

		// Get user input and length of said input
		scanf("%[^\n]%*c", input);
		input_len = strlen(input);

		// Update history to add input to the last slot and move everything else up one, deleting the current oldest command
		for(int i = 0; i < 9; i++) {
			strcpy(history[i], history[i+1]);
		}
		strcpy(history[9], input);

		// Already written: Tokenizing and parsing the input into the command structure.
		push_str(input, input_len);
		c = parse();
		print_cmd(c);

		// built-ins need to be handled by the shell process
		if (handle_builtin(c, history))
			goto done;

		// Fork : Copy yourself to a child and a parent
		// Already written: fork1() is essentialy fork() but also quits the program 
		// if fork() fails
		if((child = fork1()))
		{
			// Already written: This block runs in the parent, with variable child equal
			// to the PID of the child process in the else block below.
			int code;

			// Already written: Wait for specifically the child with the given PID
			// to die. This *should* be our only child, but it doesn't hurt to be safe. */
			while(wait(&code) != child);

			// Already written: Prints exit code of last command.
			printf("command exited with code %d\n", WEXITSTATUS(code));
		} 
		else
		{
			// Already written: This block runs in the child. runs exec_cmd and 
			// exits with the return value of exec_cmd, which is supposed to return 0.
			// Note: You will need to fill in the implementation of exec_cmd inside exec.c.
			exit(exec_cmd(c));
		}

done:
		// Already written: Release any memory associated with the command.
		free_cmd(c);
		//free(input);

		//free(cwd);
		//free(host);
		//free(user);

		//TODO: This is a good place to free memory you allocated in this loop and you don't need anymore

		return 0;
	} while(get_cur() != TOK_EOF);
}
