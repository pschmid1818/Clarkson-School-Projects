#include "shtypes.h"
#include "syscalls.h"
#include "io.h"
#include "stdio.h"
#include "string.h"
#include "parser.h"
#include "tok.h"


int handle_builtin(struct cmd *c, char history[10][100], int *processes) // c is the pointer to a cmd struct */
{
	// already written : make sure c parsed properly and if not return 0 */
	if (!c)
		return 0;

	// already written : tp is the type of the command, like Redir, background, 
	// exec, list, or pipe (shtypes.h) */
	// Note: tp is the field out of the struct that we are pointing to (using the ->)
	switch (c->tp)
	{
		// Note : only if c is an exec then it could be a built-in */
		case EXEC: // Note : EXEC is an enum (shtypes.h)
			// Already written: Echo builtin command
			// If comparing c->exec.argv[0] and "echo" gives 0 then they are 
			// equal and you loop over the other arguments and print them out.
			if (strcmp(c->exec.argv[0], "echo") == 0) 
			{
				for (int i = 1; ; i++)
					if (c->exec.argv[i])
						printf("%s ", c->exec.argv[i]);
					else
						break;
				printf("\n");
				return 1;
			}
			// Already written: Exit builtin command 
			else if (strcmp(c->exec.argv[0], "exit") == 0) 
			{
				int code = 0;
				if(c->exec.argv[1]) {
					code = atoi(c->exec.argv[1]);
				}

				wait(NULL); // waits for processes to finish

				exit(code); // Kills your process and returns code
			} 

			else if (strcmp(c->exec.argv[0], "cd") == 0) 
			{
				if(c->exec.argv[1] == NULL) {
					printf("Expected a file path\n");
				}
				else {
					chdir(c->exec.argv[1]); 
				}
			}		

			else if (strcmp(c->exec.argv[0], "pwd") == 0) 
			{
				char cwd[200];
				getcwd(cwd, sizeof(cwd));
				printf("%s\n", cwd);
			}
			// TODO: implement jobs
			else if (strcmp(c->exec.argv[0], "jobs") == 0) 
			{
				printf("Current Process IDs:\n");

				for(int i = 0; i < sizeof(processes); i++) {
					printf("[%d] : %d\n", i, processes[i]);
				}
			}

			else if (strcmp(c->exec.argv[0], "history") == 0) 
			{
				for(int i = 0; i < 10; i++) {
					printf("[%d]: %s\n", i, history[i]);
				}

				int flag = 0;

				char *temp = malloc(10 * sizeof(char));

					char *command;
						printf("Enter a number 1-9 to redo command, anything else quits: ");
						scanf("%[^\n]%*c", temp);

						if(strcmp(temp, "0") == 0|| strcmp(temp, "1") == 0|| strcmp(temp, "2") == 0 || strcmp(temp, "3") == 0 || strcmp(temp, "4") == 0 || strcmp(temp, "5") == 0 || strcmp(temp, "6") == 0 || strcmp(temp, "7") == 0 || strcmp(temp, "8") == 0 || strcmp(temp, "9") == 0) {
							int index = atoi(temp);
							struct cmd *c;

							char *toCall = history[index];
							int toCallLen = strlen(toCall);

							push_str(toCall, toCallLen);
							c = parse();
							print_cmd(c);

							handle_builtin(c, history, processes);
							flag = 1;
						}
						
			}
			// kills ubuntu with pid from getppid()
			// kills ./sh with pid from getpid()
			//auming it works without a working jobs to test it fully
			else if (strcmp(c->exec.argv[0], "kill") == 0) 
			{
				char *target = malloc(50 * sizeof(char));
				strcpy(target,c->exec.argv[1]);
				int pid = atoi(target); 
				printf("%d\n", pid);
				if(kill(pid, SIGKILL) != 0) 
					printf("Process %d does not exist\n", pid);
				else 
					printf("Process %d has been killed\n", pid);
			}
			else if (strcmp(c->exec.argv[0], "help") == 0) 
			{
				printf("Show all builtin commands   - help\n");
				printf("Display text 'n'            - echo n\n");
				printf("Display current directory   - cd\n");
				printf("Show current directory path - pwd\n");
				printf("Show current status of jobs - jobs\n");
				printf("Show command history        - history\n");
				printf("Kill process 'n'            - kill n\n");
				printf("Clear screen                - clear\n");
				printf("Exit shell                  - exit\n");
			}
			else if (strcmp(c->exec.argv[0], "clear") == 0) 
			{
				//ANSI escape code 
					// \033: ESC
					// J: erase part of screen (2 for whole screen) -> [2J
					// H: move cursor (1;1 means row 1 column 1) -> [1;1H
				printf("\033[2J\033[1;1H");
			}
			else {
				return 0;
			}
		default:
			return 0; //Note : returns 0 when you call handle_builtin in main
	}
}

/* Most of your implementation needs to be in here, so a description of this
 * function is in order:
 *
 * int exec_cmd(struct cmd *c)
 *
 * Executes a command structure. See shtypes.h for the definition of the
 * `struct cmd` structure.
 *
 * The return value is the exit code of a subprocess, if a subprocess was
 * executed and waited for. (Id est, it should be the low byte of the return
 * value from that program's main() function.) If no return code is collected,
 * the return value is 0.
 *
 * For pipes and lists, the return value is the exit code of the rightmost
 * process.
 *
 * The function does not change the assignment of file descriptors of the
 * current process--but it may fork temp processes and change their file
 * descriptors. On return, the shell is expected to remain connected to
 * its usual controlling terminal (via stdin, stdout, and stderr).
 *
 * This will not be called for builtins (values for which the function above
 * returns a nonzero value).
 */
int exec_cmd(struct cmd *c)
{
	// Don't try to execute a command if parsing failed.
	if (!c)
		return -1;

	switch (c->tp)
	{
		case EXEC:
			execvp(c->exec.argv[0], c->exec.argv);
			break;


		case PIPE:
			{
				int pipefds[2];
				pid_t p1, p2;
				
				pipe(pipefds);

				if (p1 = fork() < 0) 
					printf("Could not fork\n");
				else if(p1 == 0) {

					close(pipefds[0]);
					dup2(pipefds[1], STDOUT_FILENO);
					close(pipefds[1]);

					exec_cmd(c->pipe.left);
				}
				else {
					if (p2 = fork() < 0) 
						printf("Could not fork\n");
					else if(p2 == 0) {

						close(pipefds[1]);
						dup2(pipefds[0], STDOUT_FILENO);
						close(pipefds[0]);

						exec_cmd(c->pipe.right);
					}
					else {
						wait(NULL);
						wait(NULL);
					}
				}
			}
			break;

		case LIST:
			// The LIST case is already written */
			exec_cmd(c->list.first);
			return exec_cmd(c->list.next);
			break;

		case REDIR:
			{
				pid_t p;

				if(p = fork() < 0)
					printf("Could not fork");
				else if(p == 0) {
					if(c->redir.fd == 0) {
						int fd0 = open(c->redir.path, c->redir.mode);
						dup2(fd0, STDIN_FILENO);
						close(fd0);
					}
					if(c->redir.fd == 1) {
						int fd1 = creat(c->redir.path, c->redir.mode);
						dup2(fd1, STDOUT_FILENO);
						close(fd1);
					}

					exec_cmd(c->redir.cmd);
				}
				else 
					wait(NULL);
				break;
			}
			

		case BACK:
			return exec_cmd(c->back.cmd);
			break;

		default:
			fatal("BUG: exec_cmd unknown command type\n");
	}
	return 0;
}
