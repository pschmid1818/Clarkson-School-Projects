#include "tok.h" // Grabs characters from stdin and creates tokens 
#include "io.h" // Importing syscalls & file handling including printing & scanning
#include "shtypes.h" // Importing the command struct
#include "parser.h" // Consumes tokens and creates command structs
#include "exec.h" // Functions that handle built-ins and run programs (execvp)
#include "syscalls.h" // Import more syscalls and define fork1

//character matrix of 10 100 length strings, larger number the number the newer the command
char history[10][100] = {"", "", "", "", "", "", "", "", "", ""};
int *processes;

/*argc : number of argumnets, argv : the arguments itself */
int main(int argc, char **argv)
{
	char *input; // User input
	int input_len; // Length of user input
	struct cmd *c; // Pointer to a command struct
	int child; // Child process pid

	// Already written: Prints out a banner telling the user about the shell.
	printf("simple sh, " __DATE__ " " __TIME__ "\nPress Control+C or Control+D to exit.\n");

	// Already written: Initialize the tokenizer.
	advance();



	do {
		// Prompt for username@hostname:current/working/directory$		

		char *path = malloc(200 * sizeof(char));
		char *host = malloc(200 * sizeof(char));
		char *user;
		processes = malloc(1000 * sizeof(int));

		getcwd(path, 200 * sizeof(char));
		gethostname(host, 200 * sizeof(char));
		user = getenv("USER");

		printf("%s@%s:%s$ ", user, host, path); // Implementation

		// Get user input and length of said input
		input = malloc(200 * sizeof(char)); // User input
		scanf("%[^\n]%*c", input);
		input_len = strlen(input);

		// Update history to add input to the last slot and move everything else up one, deleting the current oldest command
		
		for(int i = 0; i < 9; i++) {
			strcpy(history[i], history[i+1]);
		}
		strcpy(history[9], input);
		

		// Already written: Tokenizing and parsing the input into the command structure.
		push_str(input, input_len);
		c = parse();
		print_cmd(c);

		// built-ins need to be handled by the shell process
		if (handle_builtin(c, history, processes))
			printf("In builtin\n");
			goto done;

		// Fork : Copy yourself to a child and a parent
		// Already written: fork1() is essentialy fork() but also quits the program 
		// if fork() fails
		if((child = fork1()))
		{
			printf("running in parent\n");

			printf("Process ID: %d\n", getpid());
			processes[sizeof(processes)] = getpid();

			// Already written: This block runs in the parent, with variable child equal
			// to the PID of the child process in the else block below.
			int code;

			// Already written: Wait for specifically the child with the given PID
			// to die. This *should* be our only child, but it doesn't hurt to be safe. */
			while(wait(&code) != child);

			// Already written: Prints exit code of last command.
			printf("command exited with code %d\n", WEXITSTATUS(code));
		} 
		else
		{

			printf("Process ID: %d\n", getpid());
			processes[sizeof(processes)] = getpid();

			// Already written: This block runs in the child. runs exec_cmd and 
			// exits with the return value of exec_cmd, which is supposed to return 0.
			// Note: You will need to fill in the implementation of exec_cmd inside exec.c.
			printf("running in child\n");
			exit(exec_cmd(c));
		}

	done:
		// Already written: Release any memory associated with the command.
		free_cmd(c);
		free(input);

		free(path);
		free(host);

	} while(1); //while(get_cur() != TOK_EOF); exit still works
}
